const sequelize = require('./db');
const comentarios = require('./models/COMENTARIOS');
const postagens = require('./models/POSTAGENS');
const usuariocomum = require('./models/USUARIOCOMUM');
const usuarioprofissional = require('./models/USUARIOPROFIS');
const denuncias = require('./models/DENUNCIAS');
const setupRelationships = require('./models/RELACOES');

(async () => {
  try {
    // Configurar relacionamentos
    setupRelationships();

    // Sincronizar o banco de dados
    await sequelize.sync({ force: true });
    console.log('Banco de dados sincronizado.');

    // // Criar um usuário
    // const user = await User.create({ 
    //     username: 'john_doe', 
    //     email: 'john@example.com' 
    // });

    // // Criar o perfil do usuário
    // const profile = await Profile.create({
    //   bio: 'Desenvolvedor apaixonado por tecnologia.',
    //   avatar: 'avatar.jpg',
    //   userId: user.id,
    // });

    // console.log('Usuário e perfil criados:', user.toJSON(), profile.toJSON());

    // Criar posts
    // const postagem1 = await Post.create({
    //   title: 'Meu primeiro post',
    //   content: 'Este é o conteúdo do meu primeiro post!',
    //   userId: user.id,
    // });

    // const post2 = await Post.create({
    //   title: 'Dicas de programação',
    //   content: 'Aqui estão algumas dicas úteis para programadores.',
    //   userId: user.id,
    // });

    // console.log('Posts criados:', post1.toJSON(), post2.toJSON());

    // Criar tags
    // const tag1 = await Tag.create({ name: 'Tecnologia' });
    // const tag2 = await Tag.create({ name: 'Programação' });

    // console.log('Tags criadas:', tag1.toJSON(), tag2.toJSON());

    // Associar tags aos posts com atributos extras
    // await post1.addTag(tag1, { through: { relevance: 5 } });
    // await post1.addTag(tag2, { through: { relevance: 3 } });
    // await post2.addTag(tag2, { through: { relevance: 4 } });

    // console.log('Tags associadas aos posts.');

    // Consultar posts com tags
    // const posts = await Post.findAll({
    //   include: {
    //     model: Tag,
    //     through: { attributes: ['assignedAt', 'relevance'] },
    //   },
    // });

    // console.log('Posts com tags:', JSON.stringify(posts, null, 2));
  } catch (error) {
    console.error('Erro ao sincronizar o banco de dados:', error);
  }
})();