const usuariocomum = require('./USUARIOCOMUM');
const usuarioprofissional = require('./USUARIOPROFIS');
const postagens = require('./POSTAGENS');
const denuncias = require('./DENUNCIAS');
const comentarios = require('./COMENTARIOS');
// const chatcomumcomum = require('./CHATCOMUMCOMUM.JS');
// const chatprofisprofis = require('./CHATPROFISPROFIS.JS');
// const chatcomumprofissional = require('./CHATCOMUMPROFIS.JS')

module.exports = () => {
  // 1-1: User -> Profile
  // User.hasOne(Profile, { foreignKey: 'userId' });
  // Profile.belongsTo(User, { foreignKey: 'userId' });

    // 1-1: User -> Profile
    // User.hasOne(Profile, { foreignKey: 'userId' });
    // Profile.belongsTo(User, { foreignKey: 'userId' });

  // 1-N: User -> Post
  // User.hasMany(Post, { foreignKey: 'userId' });
  // Post.belongsTo(User, { foreignKey: 'userId' });
      // 1-N: User -> Post
  postagens.hasMany(denuncias, { foreignKey: 'postagemId' });
  denuncias.belongsTo(postagens, { foreignKey: 'postagemId' });

  postagens.hasMany(comentarios, {foreignKey: 'postagemId'});
  comentarios.belongsTo(postagens, {foreignKey: 'postagemId'});

  // N-M: Post <-> Tag
  // Post.belongsToMany(Tag, { through: PostTag });
  // Tag.belongsToMany(Post, { through: PostTag });

   
  
  /*-------------------------------Comentarios--------------------------------*/
  comentarios.belongsToMany(usuariocomum,{ through: 'ComentarioUsuarioComum' });
  usuariocomum.belongsToMany(comentarios, { through: 'ComentariosUsuarioComum'});

  comentarios.belongsToMany(usuarioprofissional,{ through: 'ComentarioUsuarioProfissional' });
  usuarioprofissional.belongsToMany(comentarios, { through: 'ComentariosUsuarioProfissional'});

  comentarios.hasOne(postagens, { foreignKey: 'postagensId'});
  postagens.belongsTo(comentarios, { foreignKey: 'postagensId'});


   /*-------------------------------Denuncias--------------------------------*/
  denuncias.belongsToMany(usuariocomum, { through: 'UsuarioComumDenuncias'});
  usuariocomum.belongsToMany(denuncias, { through: 'UsuarioComumDenuncias'});

  denuncias.belongsToMany(usuarioprofissional, { through: 'UsuarioProfissionalDenuncias'});
  usuarioprofissional.belongsToMany(denuncias, { through: 'UsuarioProfissionalDenuncias'});

  denuncias.hasOne(postagens, { foreignKey: 'postagensId'});
  postagens.belongsTo(denuncias, { foreignKey: 'postagensId'});


  /*-------------------------------Postagens--------------------------------*/
  usuariocomum.belongsToMany(postagens, { through: 'UsuarioComumPostagens'});
  postagens.belongsToMany(usuariocomum, { through: 'UsuarioComumPostagens'});

  usuarioprofissional.belongsToMany(postagens, { through: 'UsuarioProfissionalPostagens'});
  postagens.belongsToMany(usuarioprofissional, { through: 'UsuarioProfissionalPostagens'});

   /*--------------------------------Chats--------------------------------*/
   usuarioprofissional.hasOne(usuarioprofissional, { foreignKey: 'usuarioprofissionalId' });
   usuarioprofissional.belongsTo(usuarioprofissional, { foreignKey: 'usuarioprofissionalId' });

   usuariocomum.hasOne(usuariocomum, { foreignKey: 'usuariocomumId' });
   usuariocomum.belongsTo(usuariocomum, { foreignKey: 'usuariocomumId' });

   usuariocomum.hasOne(usuarioprofissional, { foreignKey: 'usuariocomumId' } )
   usuarioprofissional.belongsTo(usuariocomum, { foreignKey: 'usuariocomumId' })
   


}