// genero varchar(10),
// senha varchar(35),
// email varchar(50),
// nome varchar(100),
// foto_perfil varchar(75),
// nickname varchar(30),
// disturbio varchar(40),
// lingua_nativa varchar(25),
// documento_medico varchar(70),
// id int auto_increment,
// primary key(id)

const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const usuariocomum = sequelize.define('usuariocomum', {
    genero: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    senha: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    email: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    nome: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    foto_perfil: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    nickname: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    disturbio: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    lingua_nativa: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    documento_medico: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
  });
  
  module.exports = usuariocomum;