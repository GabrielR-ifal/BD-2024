// id int,
// qt_msg_total varchar(15000),
// FK_usuarioprofissional_id int,
// FK_usuarioprofissional2_id int,
// foreign key (FK_usuarioprofissional_id) references UsuarioProfissional(id),
// foreign key (FK_usuarioprofissional2_id) references UsuarioProfissional(id)

const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const chatprofisprofis = sequelize.define('chatprofisprofis', {
    qt_msg_total: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
  });

  module.exports = chatprofisprofis;