// data date,
// conteudo varchar(200),
// id int auto_increment,
// primary key(id),
// FK_postagens_id int,
// foreign key (FK_postagens_id) references Postagens(id)

const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const denuncias = sequelize.define('denuncias', {
    data: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    conteudo: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    assunto: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
  });
  
  module.exports = denuncias;