// topico varchar(100),
// titulo 	varchar(100),
// assunto varchar(500),
// id int auto_increment,
// primary key(id)
// );



const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const postagens = sequelize.define('postagens', {
    topico: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    titulo: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    assunto: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
  });
  
  module.exports = postagens;