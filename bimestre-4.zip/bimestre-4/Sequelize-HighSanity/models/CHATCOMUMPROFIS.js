// id int,
// qt_msg_total varchar(15000),
// FK_usuariocomum_id int,
// FK_usuarioprofissional_id int,
// foreign key (FK_usuariocomum_id) references UsuarioComum(id),
// foreign key (FK_usuarioprofissional_id) references UsuarioProfissional(id)



const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const chatcomumprofissional = sequelize.define('chatcomumprofissional', {
    qt_msg_total: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
  });

  module.exports = chatcomumprofissional;