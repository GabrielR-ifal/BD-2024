// id int auto_increment,
// mensagem varchar(300),
// data date,
// FK_postagens_id int,
// foreign key (FK_postagens_id) references Postagens(id),
// primary key(id)

const { DataTypes } = require('sequelize');
const sequelize = require('../db');

const comentarios = sequelize.define('comentarios', {
    data: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    mensagem: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
      },
  });
  
  module.exports = comentarios;