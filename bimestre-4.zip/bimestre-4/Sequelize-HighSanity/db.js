const {Sequelize} = require('sequelize');
const sequelize = new Sequelize(
    'trabalho', // nome do banco
    'aluno.ifal', // nome do usuario
    'aluno.ifal', // senha de acesso
    {
        host: 'localhost',
        dialect: 'mysql'
    }
);
module.exports = sequelize;